package entity;

public class Cliente {
    
	//atributos
	private Integer idCliente;
	private String  nome;
	private String  email;
	private String  plano;
	private Double  valorPlano;
    private Boolean ativo;
    
	
    public  void gerarValorPlano() {
     switch(this.plano) {
    	case "PLANOUM":   this.valorPlano= 250.;
    	                  break;   
    	case "PLANODOIS": this.valorPlano= 400.;
                           break;
    	case "PLANOTRES":  this.valorPlano= 600.;
                          break;
  default: throw new IllegalArgumentException("Nao existe Plano");  
    	}
    }
    
    
	public Integer getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(Integer idCliente) {
		this.idCliente = idCliente;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPlano() {
		return plano;
	}
	public void setPlano(String plano) {
		this.plano = plano;
	}
	public Double getValorPlano() {
		return valorPlano;
	}
	public void setValorPlano(Double valorPlano) {
		this.valorPlano = valorPlano;
	}

	public Boolean getAtivo() {
		return ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}
	
	
	//tem uma area d execucao (chamado main)
	//public static void main(String args[])
	
	//main + ctrl + espaco e enter
	
   public static void main(String[] args) {

	   try {
		   //tentar
		Cliente c = new Cliente();
		    c.setIdCliente(100);
		    c.setNome("marco");
		    c.setEmail("marco@gmail.com");
		    c.setPlano("PLANOUMs");
		
		    c.gerarValorPlano();

  System.out.println(c.getNome() + ", " + c.getValorPlano());
	      } catch (Exception e) {
	    	  //desvio ...
     	e.printStackTrace(); //detalhe do erro  (Vermlho)
     	 //e.getMessage()  //imprimindo o erro
     	System.out.println(e.getMessage()); //Nao existe o plano
     	//esta trazendo a message ...
     	//syso (ctrl + espaco)
	    }
  
	   System.out.println("Nao terminou  ...");
	
  
  
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
