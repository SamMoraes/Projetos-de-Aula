package entity;

public class Aluno {

	private Integer id;
	private String nome;
	private String disciplina;
	private Double nota1;
	private Double nota2;
	private Double media = 0.; // calcular (já possui o valor de zero)
	private Boolean ativo;
	
	// saída ()
	// alt + s generate (getter and setter)
	// Um unico valor de Saída ...

	// Saída de todos
	// alt + s generate getter and setter
	public void gerarMedia() {
		this.media = (this.nota1 + this.nota2) / 2;
	}

	//escolha de inicializador (construtor)
	 
	public Aluno() {
	}
	
     //toString (SAIDA DE TODOS)
	//CONSTRUTOR ENTRADA DE TODOS 
	public Aluno(Integer id, String nome, String disciplina, Double nota1, Double nota2, Boolean ativo) {
		super();
		this.id = id;
		this.nome = nome;
		this.disciplina = disciplina;
		this.nota1 = nota1;
		this.nota2 = nota2;
		this.ativo = ativo;
	}

	@Override
	public String toString() {
		return "Aluno [id=" + id + ", nome=" + nome + ", disciplina=" + disciplina + ", nota1=" + nota1 + ", nota2="
				+ nota2 + ", media=" + media + ", ativo=" + ativo + "]";
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDisciplina() {
		return disciplina;
	}

	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}

	public Double getNota1() {
		return nota1;
	}

	public void setNota1(Double nota1) {
		this.nota1 = nota1;
	}

	public Double getNota2() {
		return nota2;
	}

	public void setNota2(Double nota2) {
		this.nota2 = nota2;
	}

	public Double getMedia() {
		return media;
	}

	public void setMedia(Double media) {
		this.media = media;
	}

	public Boolean getAtivo() {
		return ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}

	// MAIN + CTRL + ESPAÇO
	public static void main(String[] args) {
		Aluno a = new Aluno();
			a.setNome("belem");
			a.setDisciplina("java");
			a.setNota1(10.);
			a.setNota2(9d);
			a.gerarMedia();
			System.out.println("Nome: " + a.getNome() + 
					" - Media: " + a.getMedia());
			System.out.println(a);
			    //Objeto a = xoxean .... toString ...
			
			
	}

}
