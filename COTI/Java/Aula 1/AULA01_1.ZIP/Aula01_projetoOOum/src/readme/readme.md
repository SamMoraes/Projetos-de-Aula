## Suas Anotações 
## requisitos:
## Java vm (java 8)
## IDE (Eclipse)
  
    
 
 
## MVC (Dados / Controller/ Visão) 
 
    	private int numero; //primitivo (c++) Java OO (sempre Objeto)
	
# Cliente --> Classe Cliente.java
	// dados Cliente () ...
	// JaIntegerva não é vertical ...
	// classe no máximo 1000 linhas 
	//Node (Vertical )
	//Cada classe em seu Local ....
	// modificador de acesso
	//tipo 
	//nome ...
	//java (Wrappers --> Integer, Double, Long, String)
	//qualificadores : private, , proctected, public
	//private : é na Classe (somente eu visualizo)
	//em geral : 90% dos atributos sao fechados ...
	// Integer ->{Byte 8, Short 16, Integer 32 D, Long 64}
	// Float ->{Float 32, Double 64 D}
	// NUmero grande demais --> BigDecimal ... (Tera)
	//String = StringBuffer iu StringBuilder
	//Boolean (true ou false)
	//Date (Data)
	//nativos ou primimitos (byte, short, int, long, float, double}
	

####

package entity;

public class Cliente {
                   
	
	private Integer idCliente;
	private String  nome;
	private String  email;
	private String  plano;
	private Double  valorPlano;
	//para cada atributo eu tenho 
	//um método chamado getter e set entrada e saída ...
	//encapsuladores ...
	//setNome (void) _ acao
	//getNome() _ busca é um (devolve)...
	//IDE 
	//alt + s (gerar get e set)
	
	
	//function
	public Integer getIdCliente() {
		return idCliente;
	}
	//procedure
	public void setIdCliente(Integer idCliente) {
		this.idCliente = idCliente;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPlano() {
		return plano;
	}
	public void setPlano(String plano) {
		this.plano = plano;
	}
	public Double getValorPlano() {
		return valorPlano;
	}
	public void setValorPlano(Double valorPlano) {
		this.valorPlano = valorPlano;
	}
	
	
	

}

##	
package entity;

public class Cliente {
    
	//atributos
	private Integer idCliente;
	private String  nome;
	private String  email;
	private String  plano;
	private Double  valorPlano;
    private Boolean ativo;
    
	
    public  void gerarValorPlano() {
     switch(this.plano) {
    	case "PLANOUM":   this.valorPlano= 250.;
    	                  break;   
    	case "PLANODOIS": this.valorPlano= 400.;
                           break;
    	case "PLANOTRES":  this.valorPlano= 600.;
                          break;
  default: throw new IllegalArgumentException("Nao existe Plano");  
    	}
    }
    
    
	public Integer getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(Integer idCliente) {
		this.idCliente = idCliente;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPlano() {
		return plano;
	}
	public void setPlano(String plano) {
		this.plano = plano;
	}
	public Double getValorPlano() {
		return valorPlano;
	}
	public void setValorPlano(Double valorPlano) {
		this.valorPlano = valorPlano;
	}

	public Boolean getAtivo() {
		return ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}
	
	
	//tem uma area d execucao (chamado main)
	//public static void main(String args[])
	
	//main + ctrl + espaco e enter
	
   public static void main(String[] args) {
	  //Classe (Representacao)
	   //Objeto (instancia para Objeto(
	   //Cliente c (instancia)
	  //Cliente c  = new Cliente();
	   //Objeto c (new espaco de mem) Construtor
	   //new no Construtor
	   //Cliente c =new ESpaco ( Cliente())
	   Cliente c = new Cliente();
	    c.setIdCliente(100);
	    c.setNome("marco");
	    c.setEmail("marco@gmail.com");
	    c.setPlano("PLANOUMs");
	
	    c.gerarValorPlano();
	    
	    //syso (imprimir) syso (ctrl espaco e enter)
  System.out.println(c.getNome() + ", " + c.getValorPlano());
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}

