package control;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import entity.Aluno;

//Classe Diretoria ... (Gerente) Clase de Controler
public class Manager {
	private Aluno aluno; //acostumar com a ideia
	private List<Aluno> alunos; //dinamico .... (um milhao) ...
	
	
	//espaco de mem no construtor
	//inicializando no construtor ...
	public Manager() {
  this.aluno = new Aluno(); //espaço de mem (para um)
  this.alunos = new ArrayList<Aluno>(); //espaço de mem (para varios)
	}
	
	public void gerarUnidade() {
		 this.aluno = new Aluno(10,"lu", "java", 7., 10., true);
	}
	
	public void gerarGrupo() {
		 //add ==> para lista
	this.alunos.add(new Aluno(100,"mercador","java",5.,3.,true));
	this.alunos.add(new Aluno(101,"filipe","angular",2.,1.,true));
 }
	
	
	public Aluno getAluno() {
		return aluno;
	}
	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}
	public List<Aluno> getAlunos() {
		return alunos;
	}
	public void setAlunos(List<Aluno> alunos) {
		this.alunos = alunos;
	}
	
	//main + CTRL + ESPAÇO
	public static void main(String[] args) {
		//chamar ...
		Manager m  = new Manager();
		 m.gerarUnidade();
		 m.gerarGrupo();
		 
		 //syso + CTRL + ESPAÇO
		 System.out.println("Aluno: " + m.getAluno());
		 System.out.println("Lista: " + m.getAlunos());
	}
}





