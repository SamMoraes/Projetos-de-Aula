package cuidados;
public class A {
	//conceito (gerar o cheio e o vazio)
	//sobrecarga ELIMINA o IMã ...
	
	private String nome;
	
	public A(String nome) {
		this.nome = nome;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
}
