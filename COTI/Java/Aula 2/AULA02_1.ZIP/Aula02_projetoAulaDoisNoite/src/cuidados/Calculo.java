package cuidados;

public class Calculo {

	//raio parta
	//Perseguição implacavel ..
	//Só roda dando resultado no java dos (java project)
	
	//POG da Forte ..
	//Nao Imprima sempre return
	public void soma1(Double num1, Double num2) {
		System.out.println(num1 + num2);
		
	}
	
	public Double soma(Double num1, Double num2) {
		   return num1 + num2;
	}
	
}
