package entity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Pessoa {
	
	 private String nome;
	 private String sexo;
	 private Integer idade; 
	 
	 public Pessoa() {
	} 
	 
	 public Pessoa(String nome, String sexo, Integer idade) {
		this.nome = nome;
		this.sexo = sexo;
		this.idade = idade;
	}
	
	
	 @Override
	public String toString() {
		return "Pessoa [nome=" + nome + ", sexo=" + sexo + ", idade=" + idade + "]";
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public Integer getIdade() {
		return idade;
	}
	public void setIdade(Integer idade) {
		this.idade = idade;
	}
	
	
	public Boolean isNome() {
		//regra
		Pattern p = Pattern.compile("[a-z A-Z]{2,50}");
		Matcher m = p.matcher(getNome());
	    return m.matches();	//true ou false
	}
	
	//isNome()
	
	public Boolean isIdade() {
		if (idade<0 || idade>=130) {
			return false;
		}
		return true;
	}
	
	public Boolean isSexo() {
      if   (this.getSexo().equalsIgnoreCase("M")  
		 |  this.getSexo().equalsIgnoreCase("F")){
		 return true;
	  }
	 return false;
   }
	
	
	
	
	
  
	
	
	
	
	
	
	
	
	
	
	
	
	//main + ctrl + espaco e enter
   //main + ctrl + espaco de enter
	
	public static void main(String[] args) {
		   //Construtor cheio 
		  Pessoa p = new Pessoa("jose","m",30); //construtor cheio
   //alimentando os atributos
		  //xoxean
		  System.out.println( p );
		  
		  
		  Pessoa p2 = new Pessoa(); //implicito...
		     p2.setNome("lu");
		     p2.setIdade(22);
		     p2.setSexo("f");
		     System.out.println(p2);
	
		     //--------------------------------
		  Pessoa x = new Pessoa("belem1","",140);
		  String msg="";
		  //(Pattern Nao tem else if)
		  int flag=0;
		  if (!x.isNome()) {
			  msg +="Nome invalido \n";
			  flag=1;
		  }
		  if (!x.isIdade()) {
			  msg +="idade invalido  \n";
			  flag=1;
		  }
		  if (!x.isSexo()) {
			  msg +="sexo invalido \n";
			  flag =1;
		  }
		  
		 if (flag==0) { 
			 System.out.println("Dados Ok :" + x);
		 }else {
			 System.out.println("Dados invalido(s):"+ x);
			 System.out.println(msg);
		 }
		  
		 
	//glossario
		// variavel += "adicionar" .... String
		// numero +=  acumular 
		 
   // Pattern (regra)
       //Matcher A aplicacao da regra
       // matches booleano (true ou false) 		   
		 
		 
		//Integer  
		int a=10; //==
		int b=20;
		//== primitivo
		//cacadores da verdade (quando encontra a verdade)
		//ele para nao continua e entra na condicao
		//   | (ou) ( | curioso)
		
		// || (caça a verdade e para)
		//  ( |  imprensa ... curioso) ...
		if (a++==10  |  b++==30 ) {
			System.out.println("Ok:" + a + "," + b);
		}
		   //  ||
		 //oK:11, 20
		  //    |
		 //ok:11, 21
		 
//===============================================
		
		int c=10; //==
		int d=20;
		//cacador da mentira(expulsa)  // Auditor
		//&& so se for tudo verdadeiro
		if (c++==11 && d++==30 ) {
		 System.out.println("OK :" + c + "," + d);	
		}
		
		System.out.println("expulso :" + c + "," + d);
	
		//expulso : 11, 20
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		  
		
		
		  
		  
		  
		  
		
		
		
		
	}
 
	

	
	
	
	 

}
