package entity;

public class Aluno {
	// 4 Entradas (id, nome, disciplina, nota1, nota2)
	private Integer id;
	private String nome;
	private String disciplina;
	private Double  nota1;
	private Double  nota2;
	
	private Double media; //saída
	private String situacao; //saída
	  //No construtor nao tenho saída só tenho Entrada ...
	
	public Aluno(Integer id, String nome, String disciplina, 
			    Double nota1, Double nota2) {
		super();
		this.id = id;
		this.nome = nome;
		this.disciplina = disciplina;
		this.nota1 = nota1;
		this.nota2 = nota2;
	}
	
	public Aluno() {
	}
	
	 

	
	// e retorno a Classe (Insiro this) ...
	//a uma substituicao para de void para Classe
	//public void gerarMedia() {
   // this.media =(this.nota1 + this.nota2)/2;
   //	}
  //método imã do bem ...
	
 

	
	public Aluno gerarMedia() {
		this.media =(this.nota1 + this.nota2)/2;
          return this;
	}
	@Override
	public String toString() {
		return "Aluno [id=" + id + ", nome=" + nome + ", disciplina=" + disciplina + ", nota1=" + nota1 + ", nota2="
				+ nota2 + ", media=" + media + ", situacao=" + situacao + "]";
	}

	
	public Aluno gerarSituacao() {
		this.situacao = (this.media>=7)?"aprovado":
			(this.media>=5)?"recuperacao":"reprovado";
		return this;
	}


	public static void main(String[] args) {
		Aluno a = 
           new Aluno(100, "belem", "java", 6., 4.)
                     .gerarMedia().
                          gerarSituacao();
		System.out.println(a);
	}


	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDisciplina() {
		return disciplina;
	}
	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}
	public Double getNota1() {
		return nota1;
	}
	public void setNota1(Double nota1) {
		this.nota1 = nota1;
	}
	public Double getNota2() {
		return nota2;
	}
	public void setNota2(Double nota2) {
		this.nota2 = nota2;
	}

	public Double getMedia() {
		return media;
	}

	public void setMedia(Double media) {
		this.media = media;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

 
	
	
	
	
	
	
}
