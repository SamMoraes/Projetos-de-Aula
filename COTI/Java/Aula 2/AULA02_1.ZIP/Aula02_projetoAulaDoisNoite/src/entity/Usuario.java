package entity;

//Usuario é uma pessoa
//Associacao por generalizacao
public class Usuario extends Pessoa {
	// Usuario é uma pessoa
	// Herda ...

	private Integer id;
	private String login;
	private String senha;

	// quando usuario herda (busca os dados de Pessoa)

	// Cosntrutor vazio e construtor cheio

	public Usuario() {

	}

	// construtor dados dele e da superClasse

	public Usuario(Integer id, String nome, String sexo,
			Integer idade, String login, String senha) {
		super(nome, sexo, idade);
		this.id = id;
		this.login = login;
		this.senha = senha;
	}
	// toString dados dele e de cima

	@Override
	public String toString() {
		return "Usuario [id=" + id + ", login=" + login + 
				", senha=" + senha + ", getNome()=" + getNome()
				+ ", getSexo()=" + getSexo() + 
				", getIdade()=" + getIdade() + "]";
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

}
