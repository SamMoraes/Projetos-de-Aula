package controll;

import java.util.ArrayList;
import java.util.Arrays;

public class ManagerNumeros {
 static ArrayList<Integer> numeros = new ArrayList<Integer>();

 static {
	 numeros.add(1);numeros.add(10);numeros.add(4); numeros.add(5);
	 numeros.addAll(Arrays.asList(new Integer[] {6,7,8}));
  }
  public Integer menorNumero() {
	  //a.compareTo(b) --> ordenando ...
	  Integer menor = numeros.stream().
			  min((a,b)->a.compareTo(b)).get();
	  return menor;
  }
  public Integer maiorNumero() {
	  Integer maior = numeros.stream().
			  max((a,b)->a.compareTo(b)).get();
	  return maior;
  }
  
  
  public Long quantidade() {
	  Long conta = numeros.stream().count();
	  return conta;
  }
  
  //reduce (achar totais) => 0 valor inicial (Integer::sum)
  //somatorio
  public Integer soma() {
	  Integer soma = numeros.stream().reduce(0,Integer::sum);
	  return soma;
  }
  
  
  //BigData (map, reduce)
  
  
  
  public static void main(String[] args) {
	ManagerNumeros mn = new ManagerNumeros();
	   numeros.stream().forEach(x->System.out.print(x + " - "));
	 
	    System.out.println("");
	   System.out.println("maior :" + mn.maiorNumero());
	   System.out.println("menor :" + mn.menorNumero());
	   System.out.println("Soma :" + mn.soma());
	   System.out.println("Quantidade :" + mn.quantidade());
	    
}
  
  
  
  
  
  
  
  
}
