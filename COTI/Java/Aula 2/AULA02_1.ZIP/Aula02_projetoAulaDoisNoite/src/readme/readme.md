## Classe Readme ...
package entity;

public class Pessoa {
	
	//set (Alimentar)
	//get
	 private String nome;
	 private String sexo;
	 private Integer idade; //jamais armazene em BD
	 //alt + s gerar get e set
	 //alt + s gerar Construtor (vazio e cheio)
	 
	 //ctrl + espaço (Sobrecarga  de Construtor) _ tecnicamente
	 public Pessoa() {
	} //escolha (Sobrecarga)

	 //vou utilizar o set ....
	 
	  //ele irá elmiar os futuros set ....
	public Pessoa(String nome, String sexo, Integer idade) {
		this.nome = nome;
		this.sexo = sexo;
		this.idade = idade;
	}
	
	//toString() retorna tudo
	//Construtor cheio ..
	///Retornar um valor (toString()) Retorna todos os Valores ...
	@Override
	public String toString() {
		return "Pessoa [nome=" + nome + ", sexo=" + sexo + ", idade=" + idade + "]";
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public Integer getIdade() {
		return idade;
	}
	public void setIdade(Integer idade) {
		this.idade = idade;
	}


}
## 


package controll;

import java.util.ArrayList;
import java.util.Arrays;

public class ManagerNumeros {
	//stream
	//static (aloca) 
 static ArrayList<Integer> numeros = new ArrayList<Integer>();

 //anonimo static ( 1 primeiro métod a ser executado
 static {
	 //adiciona um a um 
	 numeros.add(1);numeros.add(10);numeros.add(4); numeros.add(5);
	 //adiciona um grupo ...
        numeros.addAll(Arrays.asList(new Integer[] {6,7,8}));
        //addAll (adicionar grupo)
        // Arrays.asList ((converte vetor em lista)
        //new Integer[]{valores} ... tamanho indeterminado
 }

 public static void main(String[] args) {
	 //O que é objeto ? espaço de execucao de mem
	 //static está alocado !!! (nao precisa de objeto)
	System.out.println(ManagerNumeros.numeros);
}	
 

 
 
 

}

 
 



