package entity;

import java.util.Arrays;

public class Aluno {
//Java Bean (Padrão Puro)
	
	//Regra de Negocio será validando as notas
	// verficando o resultado da Media..
	 private Integer id;
	 private String nome;
	 private String disciplina;
	 //comeco com vetor depois faco lista ...
	 private Double notas[];
	 private Double media=0.;
	 //escopo global ... Atributo
	 //obj.setNome("belem");
	 //detalhe (static)
	 public Aluno() {
	}

	 
	public Aluno(Integer id, String nome, String disciplina,
			  Double... notas) 
   {		
		this.id = id;
		this.nome = nome;
		this.disciplina = disciplina;
		this.notas = notas;
	}






	@Override
	public String toString() {
		return "Aluno [id=" + id + ", nome=" + nome +
				", disciplina=" + disciplina + ", notas=" + 
      Arrays.toString(notas)
				+ ", media=" + media + "]";
	}





	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDisciplina() {
		return disciplina;
	}
	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}
	public Double[] getNotas() {
		return notas;
	}
	//varargs ou vetor
	public void setNotas(Double... notas) {
		this.notas = notas;
	}
	public Double getMedia() {
		return media;
	}
	public void setMedia(Double media) {
		this.media = media;
	}
	 
	 //alt + s (generate getter and setter)
	 
	
	public static void print() {
		//dentro do método static só objeto
		Aluno obj  =  new Aluno();
		obj.setNome("belem");
		//nome = "belem";
	    System.out.println(obj.getNome());	
	}
	
	public void gerarMedia() {
		//escopo local 
		double soma = 0;
		for (Double pos : notas) {
			  soma += pos;
		}
		this.media = (soma)/notas.length;
	}
	
	
	
	public static void main(String args[]) {
		Aluno a =new Aluno();
		  a.setId(10);
		  a.setNome("bele");
		  a.setDisciplina("quimica");
		  a.setNotas(7d, 6d, 8.);
		
		  a.gerarMedia();
		  
		  System.out.println(a);
		
		
	}
 
	
}


========================



