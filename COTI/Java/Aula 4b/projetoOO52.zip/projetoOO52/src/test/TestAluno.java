package test;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import entity.Aluno;

public class TestAluno {
	//Teste JUNIT
	//iniciar todos os atributos
	Aluno aluno;
	
	 @Before
	public void inicio() {
		aluno = new Aluno();
		aluno.setId(10);
		aluno.setNome("luciana");
		aluno.setDisciplina("java"); //alimento as variáveis que nao irão mudar
	}
	 
	 @Test
	 public void testeNotasValidas() {
		 aluno.setNotas(7.,8.,9.);
		 int numero =  aluno.validarNotas();
		 assertTrue(numero==1);
	 }

	 @Test
	  (expected=IllegalArgumentException.class)
	  public void testeNotasInvalidas() {
		  aluno.setNotas(7.,11.,9.); 
		 int numero = aluno.validarNotas();
	 }
	 
	 
	 
	 @Test
	 public void TestCalculoMedia() {
		 double nota1=6.;
		 double nota2=7.;
		 double nota3=8.;
		 aluno.setNotas(6.,7.,8.);
		 int numero= aluno.validarNotas();
		 aluno.gerarMedia();
	assertTrue( aluno.getMedia().equals((nota1+nota2+nota3)/3) );
	 }
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	
	
	
}
