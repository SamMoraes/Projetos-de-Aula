package entity;

import java.util.Arrays;

public class Aluno {
 /*
  Regra de Negocio
     Validar as  notas
     gerarMedia() verificando a media  
  */
	 private Integer id;
	 private String nome;
	 private String disciplina;
	 private Double notas[];
	 private Double media=0.;

	 
	 public Aluno() {
	}

	 
	public Aluno(Integer id, String nome, String disciplina,
			  Double... notas) 
   {		
		this.id = id;
		this.nome = nome;
		this.disciplina = disciplina;
		this.notas = notas;
	}


	@Override
	public String toString() {
		return "Aluno [id=" + id + ", nome=" + nome +
				", disciplina=" + disciplina + ", notas=" + 
      Arrays.toString(notas)
				+ ", media=" + media + "]";
	}

	
	
	public Integer validarNotas() {
		 for (Double pos : getNotas()) {
			 if (pos<0. | pos >10.) {
	 throw new IllegalArgumentException("Nota Invalida:"+ pos);
			 }
		 }
		
		 return 1;
	}


	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDisciplina() {
		return disciplina;
	}
	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}
	public Double[] getNotas() {
		return notas;
	}
	//varargs ou vetor
	public void setNotas(Double... notas) {
		this.notas = notas;
	}
	public Double getMedia() {
		return media;
	}
	public void setMedia(Double media) {
		this.media = media;
	}
	 

	
	public static void print() {
		Aluno obj  =  new Aluno();
		obj.setNome("belem bisonho");
	    System.out.println(obj.getNome());	
	}
	
	public void gerarMedia() {

		double soma = 0;
		for (Double pos : notas) {
			  soma += pos;
		}
		this.media = (soma)/notas.length;
	}


	public static void main(String args[]) {
		Aluno a = null;
	
			try {
				a = new Aluno();
				a.setId(10);
				a.setNome("bele");
				a.setDisciplina("quimica");
				a.setNotas(12d, 6d, 8.);
				a.validarNotas();
				a.gerarMedia();

				System.out.println(a);
			} catch (Exception e) {
		        System.out.println("Error :" + e.getMessage());
				e.printStackTrace();
			}
	
	}
	
}
