package entity;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Cliente {
/*
 Calcular a Idade
 */

static SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
//Formata Date
	//Date
 static DateTimeFormatter dtf = DateTimeFormatter.
		  ofPattern("dd-MM-yyyy");

	 private Integer id;
	 private String nome;
	 private LocalDate dataNascimento;
	 
	 
	 public Cliente() {
	}
	
	 
	 
	public Cliente(Integer id, String nome, LocalDate dataNascimento) {
		this.id = id;
		this.nome = nome;
		this.dataNascimento = dataNascimento;
	}
	
	 
	public Integer  retornarIdade() {
		LocalDate dataAtual = LocalDate.now(); //data Atual
		Period period = Period.between(dataNascimento, dataAtual);
		int anos = period.getYears();
		return anos;
	}
	


	@Override
	public String toString() {
		return "Cliente [id=" + id + ", nome=" + nome +
    ", dataNascimento=" +  dtf.format(dataNascimento)  + "]";
	}


	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public LocalDate getDataNascimento() {
		return dataNascimento;
	}
	public void setDataNascimento(LocalDate dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	 
	
	
	public static void main(String[] args) {
	  
		Cliente obj= new Cliente();
      try {
    	   obj.setId(10);
    	   obj.setNome("belem");
           obj.setDataNascimento( LocalDate.of(1973,1,28) );
    	   System.out.println(obj);
    	   
    	   System.out.println("Idade:" + obj.retornarIdade());
           
	  }catch(Exception ex) {
		  System.out.println("Error :" + ex.getMessage());
	  }
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	 
	
}
