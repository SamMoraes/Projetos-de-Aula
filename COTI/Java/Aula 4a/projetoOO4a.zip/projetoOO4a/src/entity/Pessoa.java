package entity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

//ordenar (compareTo)
public class Pessoa implements Comparable<Pessoa> {

	private Integer id;
	private String nome;
	private String sexo;
	
	public Pessoa() {
	
	}

	
	public Pessoa(Integer id, String nome, String sexo) {
		this.id = id;
		this.nome = nome;
		this.sexo = sexo;
	}

		
		

	@Override
	public String toString() {
		return "Pessoa [id=" + id + ", nome=" + nome + ", sexo=" + sexo + "]";
	}


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	//Criterio de Ordenacao aqui default pelo Id...
	@Override
	public int compareTo(Pessoa p) {
		//ordenando id com getId() ... Ascendente
		return this.id.compareTo(p.getId());
	}
	
	
	
	public static void main(String[] args) {
		
		//exemplo ....
		List<Pessoa> lista = new ArrayList<Pessoa>();
		
		Pessoa p1 = new Pessoa(5,"belem","m");
		Pessoa p2 = new Pessoa(3,"carlos","m");
		Pessoa p3 = new Pessoa(8,"lu","f");
		
		
		 lista.addAll( Arrays.asList(p1,p2,p3)  );
		   //lista.add(p1); lista.add(p2); lista.add(p3);
		 
		 Collections.sort(lista);
		
		 System.out.println(lista);
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
