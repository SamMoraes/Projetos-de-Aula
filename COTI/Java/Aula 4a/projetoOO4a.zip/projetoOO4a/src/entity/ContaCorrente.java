package entity;

public class ContaCorrente extends Conta {

 
	//Quando estou programando em ContaCorrente estou sobrescrevendo
	//gerarDeposito da Classe abstrata
	//por mudar o formato da atitude é um Polimorfismo ...
	@Override
	public void gerarDeposito() {
	   setSaldo(getSaldo() + getDeposito());

	}

	@Override
	public void gerarRetirada() {
		if (getRetirada()<=getSaldo()) {
         setSaldo(getSaldo() - getRetirada()  );
		}else {
	 throw new IllegalArgumentException("Saldo insuficiente ...");
		} 
	}

}
