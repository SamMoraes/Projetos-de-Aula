package entity;

import java.util.Date;

public class MainConta {
	
	public static void main(String[] args) {
		//Nao estou dando new na Classe Abstrata
		//estou dando new para criar o Vetor ....
		
		Conta c[] = new Conta[2];
	try {	 
		 c[0]= new ContaPoupanca(); //new () (cria espaço de mem)
		 c[0].setNome("lu");
		 c[0].setDataHora(new Date());
		 c[0].setSaldo(30000.);
		 c[0].setDeposito(5000.);
		 c[0].gerarDeposito();
		
		 System.out.println(c[0]);
	
		 c[1]= new ContaCorrente();
		 c[1].setNome("rafael");
		 c[1].setDataHora(new Date());
		 c[1].setSaldo(1000.);
		 c[1].setDeposito(0.);
		 c[1].setRetirada(2000.);
		 
		 c[1].gerarRetirada();
		 
		 System.out.println(c[1]);
		 
	}catch(Exception ex) {
		System.out.println(ex.getMessage());
	}
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
	}
	

}
