package entity;

import java.text.SimpleDateFormat;
import java.util.Date;

public abstract class Conta {
	
	//As RN estão nos metodos abstratos (adicionar os dados mesmo)
	private String nome;
	private Double saldo=0.;
	private Double deposito=0.;
	private Double retirada=0.;
	private Date dataHora;
	
	// serao duas contas (poupanca) depositar (-10)...
	//sobrescrita
	//polimorfismo ...
	public abstract void  gerarDeposito(); //serão feito na heranca
	// serao duas contas (poupanca) depositar (-20)...
	public abstract void  gerarRetirada();
	
	@Override
	public String toString() {
		return "Conta [nome=" + nome + ", saldo=" + saldo +
				", deposito=" + deposito + ", retirada=" + 
				getRetirada() +", dataHora=" 
            +new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").
             format(dataHora) + "]";
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Double getSaldo() {
		return saldo;
	}
	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}
	public Double getDeposito() {
		return deposito;
	}
	public void setDeposito(Double deposito) {
		this.deposito = deposito;
	}
	public Date getDataHora() {
		return dataHora;
	}
	public void setDataHora(Date dataHora) {
		this.dataHora = dataHora;
	}
	public Double getRetirada() {
		return retirada;
	}
	public void setRetirada(Double retirada) {
		this.retirada = retirada;
	}
	
	 

}
