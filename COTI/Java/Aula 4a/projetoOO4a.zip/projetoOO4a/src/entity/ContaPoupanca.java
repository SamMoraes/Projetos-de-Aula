package entity;

public class ContaPoupanca  extends Conta{

	@Override
	public void gerarDeposito() {
		  setSaldo(getSaldo() + getDeposito() -10. );
		
	}

	@Override
	public void gerarRetirada() {
    if (getRetirada()<=(getSaldo()+20) ) {
	  setSaldo(getSaldo() - getRetirada() -20.  );
			}else {
		 throw new IllegalArgumentException("Saldo insuficiente ...");
			} 
		
	}

}
