package io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;

import entity.Login;

//Arquivo é uma Interface
//is a
//A Classe implementa A ação da regra de Negocio ...
public class Arquivo implements IArquivo {

	 FileWriter fw;
	@Override
	public void registrar(Login lg) throws Exception {
		//c:\temp\dados.txt                     (false)
            fw = new FileWriter("/tmp/dados.txt", false);
		   fw.write(lg.toString());
		   fw.flush();
		   fw.close();
	}
	
  FileReader fr;
	@Override
	public String logar() throws Exception {
          fr = new FileReader("/tmp/dados.txt");
          BufferedReader bf = new BufferedReader(fr);
          String linha="";
          if((linha = bf.readLine())!=null);
		return linha;
	}


}
