package io;

import entity.Login;


public interface IArquivo {
	
	//Virtual (abstrato) 
	 public void registrar(Login lg) throws Exception;
	 
		//Virtual (abstrato)
	 public String logar() throws Exception;

}

//Classe que irá Implementar a Interface ...