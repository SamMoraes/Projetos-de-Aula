package main;

import entity.Login;
import io.Arquivo;
import io.IArquivo;

public class Main {

	
	
	
	public static void main(String[] args) {
		
   Login l = new Login(11, "jose@gmail.com", "123", "jose");
  try {
         IArquivo arq = new Arquivo();
          arq.registrar(l);
          System.out.println("Dados Ok ...");
  
          
  
      String dad = "casa com pipoca e assistindo java ";
       String divisao[] = dad.split("e");
       
       
       System.out.println("======================");
        System.out.println(divisao[0]);
        System.out.println(divisao[1]);
 
         String dados[]= arq.logar().split(",");
                     
         Login loga = new Login();
         
             loga.setLogin("belem@gmail.com");
             loga.setSenha("123");
         
        System.out.println("comparando login:"+
           loga.getLogin().equals(dados[1]));
         System.out.println("comprando senha:" +
           loga.getSenha().equals(dados[3])); 
          
          
          
      }catch(Exception ex) {
	    ex.printStackTrace();
      }
		
  
  
  
  
		
	}
	
	
	
}
