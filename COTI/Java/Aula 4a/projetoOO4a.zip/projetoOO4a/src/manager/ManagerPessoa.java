package manager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import entity.Pessoa;

public class ManagerPessoa {

	public static List<Pessoa> pessoas = new ArrayList<Pessoa>();
	
	static {
	  pessoas.add(new Pessoa(10,"lu","f"));
	  pessoas.add(new Pessoa(5,"rafa","m"));
	  pessoas.add(new Pessoa(8,"carlos","m"));
	}
	
	
	public void ordenarNome() {
		Comparator<Pessoa> comp =
       (a,b)-> a.getNome().compareTo(b.getNome()); 
       Collections.sort(pessoas, comp);
	}
	
	
	public void atualizarNome() {
	String  pessoa= 
  pessoas.stream().filter(res-> res.getId().equals(10))
 .map(rs->""+ rs.getId() + "," + "luciana" + "," + rs.getSexo())
 .collect(Collectors.toList()).get(0);
 

	pessoas.set(1,new Pessoa(10,"luciana","f"));
  
	System.out.println("\n" + pessoa);
    System.out.println("\n" + pessoas);
	}
	
	
	public static void main(String[] args) {
		ManagerPessoa mb = new ManagerPessoa();
		mb.ordenarNome();
		 System.out.println(mb.pessoas);
		 
		 mb.atualizarNome();
		
	}
	
	
	
	
	
	
	
	
	
	
}
