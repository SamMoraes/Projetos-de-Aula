package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.Cliente;


@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
    public Controller() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 //envio na web (string)
		
		Cliente c  =new Cliente(null,request.getParameter("nome"),
				    request.getParameter("email"),
				    request.getParameter("sexo")
				);
		try {
		  
			if(c.getNome().equalsIgnoreCase("rafael")) {
				throw new Exception("Nome Invalido ...." + c.getNome());
			}
			
			request.setAttribute("cliente", c);
			
			
			
		}catch(Exception ex) {
			request.setAttribute("msgerror", ex.getMessage());
		}
		
    request.getRequestDispatcher("sistema.jsp")
		.forward(request, response);
	
		
	}

}
