package io;

import entity.Cliente;

public interface IArquivo {

	 public void  abrir()throws Exception;
	 
	 public void gravar(Cliente c)throws Exception;
	 
	 public void fechar()throws Exception;
	
	
	
}
