package io;

import java.io.FileWriter;

import com.google.gson.Gson;

import entity.Cliente;

public class ArquivoCliente implements IArquivo{

	FileWriter fw ;
	@Override
	public void abrir() throws Exception {
        fw = new FileWriter("/tmp/cliente.json",false);
		
	}

	@Override
	public void gravar(Cliente c) throws Exception {
		fw.write(new Gson().toJson(c));
	   fw.flush();	
	}

	@Override
	public void fechar() throws Exception {
		fw.close();
	}

}
