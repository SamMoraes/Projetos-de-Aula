package email;

import org.apache.commons.mail.Email;
import org.apache.commons.mail.HtmlEmail;
import entity.Usuario;

public class EnviarEmail {
	// adicionar os jar do mail
	// loguei ou criei uma conta no mailtrap
	/*
	 * play.mailer { host = "smtp.mailtrap.io" port = 2525 ssl = no tls = yes user =
	 * "3d80cc6d713b67" password = "7c383cd2af7940" }
	 */

	public static final String HOSTNAME = "smtp.mailtrap.io";
	public static final Integer PORT = 2525;
	public static final Boolean SSL = false;
	public static final Boolean TLS = true;
	public static final String USERNAME = "3d80cc6d713b67";
	public static final String PASSWORD = "7c383cd2af7940";

	// Estou me Conectando
	public static Email conectaEmail() throws Exception {
		HtmlEmail mail = new HtmlEmail();
		mail.setHostName(HOSTNAME);
		mail.setSmtpPort(PORT);
		mail.setAuthentication(USERNAME, PASSWORD);
		mail.setTLS(TLS);
		mail.setSSL(SSL);
		return mail;
	}

	public static String enviarEmail(Usuario u) throws Throwable {
		HtmlEmail email = new HtmlEmail();
		email = (HtmlEmail) conectaEmail();
		email.setFrom("cotiead@gmail.com");
		email.setSubject("Seja Bem Vindo ao Ambiente Coti EAD");
		email.addTo(u.getEmail());
		email.setMsg("<h2>::: "
				+ "Entre no site www.cotiead.com.br</h2>" + 
				"<hr/><br/> seja bem Vindo ao Coti = <b>"
				+ u.getNome() + "</b>");
		Thread.sleep(1000);// da um tempo de 1 segundo
		email.send(); //envia o email (mailtrap)
		return "Email enviado Com Sucesso";
	}
	
	public static void main(String[] args) {
	 Usuario u =
	 new Usuario(100, "belem", "profedsonbelem@gmail.com","123");
	 
	 	try {
		String resp =  EnviarEmail.enviarEmail(u);
		 
		 System.out.println(resp);
		
	 	}catch(Throwable tx) {
	 	   tx.printStackTrace();	
	 	}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
