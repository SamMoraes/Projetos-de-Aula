package controll;

import java.util.ArrayList;
import java.util.List;

import entity.Usuario;

public class ControllerUsuario {
//Mockado
public static List<Usuario> usuarios = new ArrayList<Usuario>();
static {
	Usuario u1 = new Usuario(10,"lu","lu@gmail.com","123");
	 u1.gerarCriptografia();
	Usuario u2 = new Usuario(20,"marcos","marcos@gmail.com","123");
	 u2.gerarCriptografia();
	usuarios.add(u1);
	usuarios.add(u2);
}

 public static void adicionar(Usuario u) {
	     u.gerarCriptografia();
	     usuarios.add(u);
 }

 public static int count() {
	 return usuarios.size();
 }
  public static List<Usuario> findAll(){
	  return usuarios;
  }
  
//stream
 public static Usuario findById(Integer id) {
	 Usuario resposta = usuarios.stream().filter(a-> {
	   return a.getId().equals(id);
	 }).findAny().orElse(null);
	return resposta; 
 }

 public static void main(String[] args) {
	  ControllerUsuario.findAll().stream().forEach(x->
	     System.out.println(x.getNome() +"," + x.getEmail())
			  ); 
	  
	 System.out.println(count());
	 
	 Usuario y = new Usuario(30,"belem","bel@gmail.com","123");
	 ControllerUsuario.adicionar(y);
	 
	 System.out.println("H==>" + findAll());
	 System.out.println(count());
	 
	 Usuario resp = findById(3);
	 if (resp==null) {
		 System.out.println("Nao Encontrado o Usuario");
	 }else {
		 System.out.println("Encontrado:" + resp);
	 }
	 
	 
	 
	 
	 
	 
	 
	 
}
 
 
 
 
 

	
	
}
