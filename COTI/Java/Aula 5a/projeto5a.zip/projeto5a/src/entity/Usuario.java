package entity;

import org.jcommon.encryption.SimpleMD5;

//Heranca
public class Usuario extends Pessoa{
   
	//public int a = 5000; //certificacao ...
	private Integer id;
	private String  senha;
	
	public Usuario() {
	
	}



 public Usuario( Integer id,String nome, String email, String senha) {
		super(nome, email);
		this.id = id;
		this.senha = senha;
	}




	@Override
public String toString() {
	return "Usuario [id=" + id + ", senha=" + senha +
", getNome()=" + getNome() + ", getEmail()=" + getEmail() + "]";
}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	//Sobrescrita (Só Ocorre quando estou em heranca ou impl de interface)

	public void display() {
		System.out.println("Class Usuario :" + this);
	}
	
	public void gerarCriptografia() {
		SimpleMD5 md5 = new SimpleMD5(senha,
   "123www.cotiinformatica.com.br@mySecret1+1=1");
		setSenha(md5.toHexString());
	}
	

	
	
	
	public static void main(String[] args) {
		
//		Pessoa p = new Pessoa(); // (nome,email)
//		Pessoa p2 = new Usuario(); //Classe Abstrata x interface
//		//sobrescrita ((métodos iguais) = subclasse)
//		p2.display();
//		//Heranca
//		Usuario u = new Usuario();
//	
//	 //	 Usuario x = new Pessoa();
//	//	System.out.println(p2.a);
//		//método sobrescreve
//		//atributo não sobrescreve...
//		
		Usuario u = new Usuario(10,"lu","lu@gmail.com","123");
		
		u.gerarCriptografia();
		
		System.out.println(u);
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	

}
