package entity;

//classe Entidade
public class Funcionario  implements IFuncionario{
  //desconto 500 programador, 800 arquiteto, 300 teste
	//atributos
	private Integer idFuncionario;
	private String nome;
	private Double salario;
	private String cargo;
	private Double desconto;
	
	public Funcionario() {
	}
	
	public Funcionario(Integer idFuncionario, String nome, Double salario, String cargo, Double desconto) {
		super();
		this.idFuncionario = idFuncionario;
		this.nome = nome;
		this.salario = salario;
		this.cargo = cargo;
		this.desconto = desconto;
	}



	@Override
	public String toString() {
		return "Funcionario [idFuncionario=" + idFuncionario + ", nome=" + nome + ", salario=" + salario + ", cargo="
				+ cargo + ", desconto=" + desconto + "]";
	}


 //gerarSalario () _ Sobrescrevendo o Método 
	@Override
	public void gerarSalario() throws Exception {
		switch(this.cargo) {
		case "teste" : setDesconto(300.);
		                   break;  
		case "programador" : setDesconto(500.);
                            break;  
		case "arquiteto" : setDesconto(800.);
        					break;
        default : throw new Exception("Cargo nao Definido");        					
		}
	  
	     this.setSalario(this.getSalario() - getDesconto());	
	}
//Interface
//	(Classe que tem as regras de negocio que serão implementadas)
//Quando vira classe A Interfafce implementa a Regra de Negocio...	

	
	
	public Integer getIdFuncionario() {
		return idFuncionario;
	}



	public void setIdFuncionario(Integer idFuncionario) {
		this.idFuncionario = idFuncionario;
	}



	public String getNome() {
		return nome;
	}



	public void setNome(String nome) {
		this.nome = nome;
	}



	public Double getSalario() {
		return salario;
	}



	public void setSalario(Double salario) {
		this.salario = salario;
	}



	public String getCargo() {
		return cargo;
	}



	public void setCargo(String cargo) {
		this.cargo = cargo;
	}



	public Double getDesconto() {
		return desconto;
	}



	public void setDesconto(Double desconto) {
		this.desconto = desconto;
	}

	
	
	

}
