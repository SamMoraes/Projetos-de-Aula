package entity;

public class Cliente{

	private Integer idCliente;
	private String nome;
	private String email;
	//Associacao Unidirecional
	//Cliente HasOne ...
	private Endereco endereco;
	
	public Cliente() {
	}

	
	public Cliente(Integer idCliente, String nome, String email) {
		super();
		this.idCliente = idCliente;
		this.nome = nome;
		this.email = email;
	}

      

 
	@Override
	public String toString() {
		return "Cliente [idCliente=" + idCliente + ", nome=" + nome + ", email=" + email + "]";
	}


	public Integer getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(Integer idCliente) {
		this.idCliente = idCliente;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}


	public Endereco getEndereco() {
		return endereco;
	}


	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	
	public static void main(String[] args) {
		//Rodar Endereco no Cliente
		
		Cliente c =new Cliente();
		   c.setNome("Luciana");
           c.setEndereco(new Endereco("Centro","Rio de Janeiro"));
         //Endereco faz parte do Cliente
           //Cliente tem Endereco 
           //Endereco está sendo executado dentro do Cliente ...
           //Relacionamento mais forte sempre é composição
           //Agregação é forte mais não tanto ...
           
	}
	
	
	
	
}
