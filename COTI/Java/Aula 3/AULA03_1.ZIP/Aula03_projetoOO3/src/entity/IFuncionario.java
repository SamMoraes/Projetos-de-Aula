package entity;

public interface IFuncionario {

	           //throws Exception (citar Erros Fortes)
	       //Erros que Herdam RuntimeExeption, erros fracos
	       //Erro numero Throwable ...
	       //citar 
	 public void gerarSalario() throws Exception;
	   //IllegalArgumentException Erro Fraco ...
	  //nao precisa nem de throws 
	  //throws (grava) 
	
}
//Cada Classe que Implementa a interface, aplica a regra de
//negocio da interface ... 
//EJB (todo método negocio) interface ...
//throws e throw (lancar)
//try (tentar) e  (catch)