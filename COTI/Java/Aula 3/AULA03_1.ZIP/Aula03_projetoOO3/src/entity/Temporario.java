package entity;

public class Temporario implements IFuncionario{

	//cargo _ estagiario desconto ...(500)
	// professor traine _ desconto (1000.)
	
	private Integer idFuncionario;
	private String nome;
	private Double salario;
	private String cargo;
	private Double desconto;
	
	@Override
	public void gerarSalario() throws Exception {
	    switch(cargo){
	    case "estagiario" : setDesconto(500.);
	                    break;
	    case "professor traine": setDesconto(1000.);	                    
	                         break;  
        default : throw new Exception("Tu nao existe nao ...");	                         
	    }
     this.setSalario(this.getSalario() - this.getDesconto());
	}
	
	
	public Temporario(){
	}
    
	
	
	
	public Temporario(Integer idFuncionario, String nome, Double salario, String cargo, Double desconto) {
		super();
		this.idFuncionario = idFuncionario;
		this.nome = nome;
		this.salario = salario;
		this.cargo = cargo;
		this.desconto = desconto;
	}
	
	
	@Override
	public String toString() {
		return "Temporario [idFuncionario=" + idFuncionario + ", nome=" + nome + ", salario=" + salario + ", cargo="
				+ cargo + ", desconto=" + desconto + "]";
	}


	public Integer getIdFuncionario() {
		return idFuncionario;
	}

	public void setIdFuncionario(Integer idFuncionario) {
		this.idFuncionario = idFuncionario;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Double getSalario() {
		return salario;
	}

	public void setSalario(Double salario) {
		this.salario = salario;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public Double getDesconto() {
		return desconto;
	}

	public void setDesconto(Double desconto) {
		this.desconto = desconto;
	}
	

}
