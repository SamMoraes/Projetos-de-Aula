package entity;

public class Main {

	public static void main(String[] args) {
	
		Funcionario ifu =new Funcionario();
		try {
			//throws te Obriga a trablahar dentro de try e catch

		ifu.setIdFuncionario(5);
		ifu.setNome("rafael");
		ifu.setCargo("programador");
		ifu.setSalario(7000.);

		ifu.gerarSalario(); //toda vez que rodo throws
		
		 System.out.println(ifu.getNome());
		 System.out.println(ifu.getCargo());
		 System.out.println(ifu.getSalario());
		
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
	}
	
}
