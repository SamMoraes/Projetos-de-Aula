package java8;

@FunctionalInterface
public interface IFuncional {
       //Programacao Funcional (MATEMATICA) 
     // saida texto        //1 numero Entrada
	public String operacao(Integer numero);
}
