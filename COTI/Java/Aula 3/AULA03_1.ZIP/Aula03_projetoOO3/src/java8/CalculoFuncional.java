package java8;

public class CalculoFuncional {
//Funcional (OO) Lambda
	
	 public static IFuncional metade = (a)->"Metade:" +  (a/2);

	 public static IFuncional parouimpar = (a)->(a%2==0) ? "par:"+a  
		                              :"Impar :" + a;

 public static IFuncional raiz = (a)-> "Raiz:" + (Math.sqrt(a));  
        
	
 
 public static void main(String[] args) {
	
	 
	  System.out.println(metade.operacao(10));
	  System.out.println(parouimpar.operacao(4));
	  System.out.println(raiz.operacao(9));
	 
}
 
}
