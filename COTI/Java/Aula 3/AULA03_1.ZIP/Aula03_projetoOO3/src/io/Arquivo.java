package io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class Arquivo {
	//Gravar
  FileWriter fw;
   public void gravar(Usuario u) throws Exception{
	    fw = new FileWriter
 ("/run/user/1000/gvfs/smb-share:server=coti204maq00,share=rede/"
  + "chat1.log",true); //adicionar (false é sobrescrever)
	    //gravar nome, mensagem, data
	    fw.write(u.toString() + "\n"); //enter
	    fw.close(); //fechar
   }
   
   
   FileReader fr;
   public List<String> ler()throws Exception{
	   //Busar a lista de linhas (gravadas)
	   List<String> lista = new ArrayList<String>();
	   //Apontando para o Arquivo
	   fr = new FileReader("/run/user/1000/gvfs"
 + "/smb-share:server=coti204maq00,share=rede/chat1.log");
	   //TRazendo o Arquivo ...
	   BufferedReader bf = new BufferedReader(fr);
	   String s="";
	   //Buscando a linha do arquivo (senao chegou a fim) 
	   while((s=bf.readLine())!=null) { //!=null nao chegou
		   lista.add(s + "\n");
	   }
	   bf.close();
	   fr.close();
	   return lista;
   }
 
   public static void main(String[] args) {
	try {
		
   Arquivo arq=new Arquivo(); 
   System.out.println("... Mensagens gravadas...");
   System.out.println(arq.ler()); //Leitura do que está gravado
   
   
   System.out.println("Gravando ..."); 
Usuario usu = new Usuario("belem","Sexta Treze... Tadam..");  
	  arq.gravar(usu);    //gravo a Mensagem
	  
   System.out.println("... Novas Mensagens ...");
   System.out.println(arq.ler()); //Atualizo a Listagem ...
     
	}catch(Exception ex) {
	 ex.printStackTrace();	
	}
	   
}
   
   
   
   

}
