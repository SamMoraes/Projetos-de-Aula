package io;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Usuario {

	 //Formatar a Data ...
	//mes-dia-ano
	//formatar é como eu queroi ver ...
	
	static SimpleDateFormat sdf =
			 new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
	private String nome;
	private String mensagem;
	
	private Date data=new Date(); //data de agora ... now()

	public Usuario() {
	}
	public Usuario(String nome, String mensagem) {
		this.nome = nome;
		this.mensagem = mensagem;
	}
	@Override
	public String toString() {
		return "Usuario [nome=" + nome + ", mensagem="
	     + mensagem +  " ,data=" + sdf.format(data) +
	     "]";
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getMensagem() {
		return mensagem;
	}
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}


	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}
	
	
	
	
	
	
}
