package br.com.athenas.requests;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PessoaPesoIdealRequest {
	
	private Integer idPessoa;
}
