package br.com.athenas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiPessoaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiPessoaApplication.class, args);
	}

}
