package br.com.athenas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiPessoaApplicationTests {

	@Test
	void contextLoads() {
	}

}
